from flask_wtf import FlaskForm
from wtforms import SubmitField, SelectField


class NewsForm(FlaskForm):
    select = SelectField("Выбор", choices=['Чрезвычайные ситуации', 'Знаки пожарной безопасности', "Приказ 477н. Приложение 1", "Приказ 477н. Приложение 2"])
    submit = SubmitField('Применить')
